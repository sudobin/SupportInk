using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Interop;
using System.Windows.Media;

namespace SupportInk;
public partial class OverlayWindow : Window
{
    private nint _hwnd; private bool _clickThrough;
    public bool IsClickThrough => _clickThrough;
    public event EventHandler? ModeChanged;
    public OverlayWindow()
    {
        InitializeComponent();
        Left=SystemParameters.VirtualScreenLeft; Top=SystemParameters.VirtualScreenTop;
        Width=SystemParameters.VirtualScreenWidth; Height=SystemParameters.VirtualScreenHeight;
        Ink.DefaultDrawingAttributes = PenAttributes(Colors.Red, 4, false);
        SourceInitialized += (_,__) => { _hwnd=new WindowInteropHelper(this).Handle; ApplyStyles(); };
    }
    public static DrawingAttributes PenAttributes(Color color,double size,bool highlighter) => new() { Color=color, Width=size, Height=size, FitToCurve=true, IsHighlighter=highlighter, StylusTip=StylusTip.Ellipse };
    private void ApplyStyles()
    {
        var style=(long)NativeMethods.GetWindowLongPtr(_hwnd,NativeMethods.GWL_EXSTYLE);
        style |= NativeMethods.WS_EX_TOOLWINDOW | NativeMethods.WS_EX_NOACTIVATE;
        if(_clickThrough) style |= NativeMethods.WS_EX_TRANSPARENT; else style &= ~NativeMethods.WS_EX_TRANSPARENT;
        NativeMethods.SetWindowLongPtr(_hwnd,NativeMethods.GWL_EXSTYLE,(nint)style);
        Ink.IsHitTestVisible=!_clickThrough;
    }
    public void SetClickThrough(bool value){_clickThrough=value; if(_hwnd!=0) ApplyStyles(); ModeChanged?.Invoke(this,EventArgs.Empty);}
    public void ToggleClickThrough()=>SetClickThrough(!_clickThrough);
    public void SetPen(Color color,double size,bool highlighter=false){SetClickThrough(false); Ink.EditingMode=InkCanvasEditingMode.Ink; Ink.DefaultDrawingAttributes=PenAttributes(color,size,highlighter);}
    public void SetEraser(){SetClickThrough(false); Ink.EditingMode=InkCanvasEditingMode.EraseByStroke;}
    public void Undo(){if(Ink.Strokes.Count>0) Ink.Strokes.Remove(Ink.Strokes[^1]);}
    public void Clear()=>Ink.Strokes.Clear();
}
