# SupportInk

A Windows 10/11 live-screen annotation overlay for customer support sessions. The background application remains active; use **Ctrl+Shift+D** to switch between Draw and Interact modes.

## Included
- Multi-monitor virtual-desktop overlay
- Pen, highlighter, stroke eraser, undo, clear
- Click-through interaction mode
- Global Ctrl+Shift+D hotkey
- Floating draggable toolbar and system tray
- Per-monitor-V2 DPI manifest; runs as standard user

## Build
1. Install Visual Studio 2026 with **.NET desktop development** and the .NET 10 SDK.
2. Open `SupportInk.slnx`, restore packages, select x64/Any CPU, and build Release.
3. Or run: `dotnet restore`, `dotnet test`, `dotnet publish src/SupportInk/SupportInk.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true`.

## Security and support-session rules
- The app has no network, telemetry, recording, clipboard capture, or elevation code.
- Annotations are local and are not saved.
- Verify customer consent before screen sharing or annotation.
- Test whether your meeting/remote-support capture method includes topmost layered windows. Window-only sharing may omit the overlay; share the monitor when permitted.
- Do not draw or retain customer secrets. Use your organisation's approved software distribution and code-signing process.

## Before production deployment
This is a functional engineering baseline, not a certified finished product. Complete: signed MSIX installer, enterprise code signing, crash logging with redaction, UI Automation accessibility, pen/touch testing, mixed-DPI monitor tests, RDP/AVD/Teams/Zoom/Webex validation, secure update channel, threat model, SBOM, privacy review, and pilot rollout.

## Suggested acceptance gates
- 8-hour soak with <150 MB working set and no handle growth
- Drawing latency p95 <25 ms on target hardware
- 100 mode toggles with no lost input
- Mixed 100%/150%/200% DPI monitor coverage
- No overlay/input lockout after display reconnect, sleep/resume, UAC, or RDP reconnect
