namespace SupportInk;
public enum OverlayMode { Live, Freeze, Whiteboard }
