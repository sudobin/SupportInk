using System.Windows;
using System.Windows.Controls;
using System.Windows.Ink;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Forms = System.Windows.Forms;

namespace SupportInk;
public partial class OverlayWindow : Window
{
    private nint _hwnd; private bool _clickThrough;
    public bool IsClickThrough => _clickThrough;
    public OverlayMode Mode { get; private set; } = OverlayMode.Live;
    public event EventHandler? ModeChanged;
    public OverlayWindow(){InitializeComponent(); Left=SystemParameters.VirtualScreenLeft; Top=SystemParameters.VirtualScreenTop; Width=SystemParameters.VirtualScreenWidth; Height=SystemParameters.VirtualScreenHeight; Ink.DefaultDrawingAttributes=PenAttributes(Colors.Red,4,false); SourceInitialized+=(_,__)=>{_hwnd=new WindowInteropHelper(this).Handle;ApplyStyles();};}
    public static DrawingAttributes PenAttributes(Color color,double size,bool highlighter)=>new(){Color=color,Width=size,Height=size,FitToCurve=true,IsHighlighter=highlighter,StylusTip=StylusTip.Ellipse};
    private void ApplyStyles(){var style=(long)NativeMethods.GetWindowLongPtr(_hwnd,NativeMethods.GWL_EXSTYLE); style|=NativeMethods.WS_EX_TOOLWINDOW|NativeMethods.WS_EX_NOACTIVATE; if(_clickThrough)style|=NativeMethods.WS_EX_TRANSPARENT;else style&=~NativeMethods.WS_EX_TRANSPARENT; NativeMethods.SetWindowLongPtr(_hwnd,NativeMethods.GWL_EXSTYLE,(nint)style);Ink.IsHitTestVisible=!_clickThrough;}
    public void SetClickThrough(bool v){_clickThrough=v;if(_hwnd!=0)ApplyStyles();ModeChanged?.Invoke(this,EventArgs.Empty);} public void ToggleClickThrough()=>SetClickThrough(!_clickThrough);
    public void SetPen(Color c,double s,bool h=false){SetClickThrough(false);Ink.EditingMode=InkCanvasEditingMode.Ink;Ink.DefaultDrawingAttributes=PenAttributes(c,s,h);} public void SetEraser(){SetClickThrough(false);Ink.EditingMode=InkCanvasEditingMode.EraseByStroke;} public void Undo(){if(Ink.Strokes.Count>0)Ink.Strokes.Remove(Ink.Strokes[^1]);} public void Clear()=>Ink.Strokes.Clear();
    public void SetLive(){Mode=OverlayMode.Live; FrozenImage.Source=null;FrozenImage.Visibility=Visibility.Collapsed;Whiteboard.Visibility=Visibility.Collapsed;Surface.Background=new SolidColorBrush(Color.FromArgb(1,0,0,0));SetClickThrough(false);ModeChanged?.Invoke(this,EventArgs.Empty);}
    public void SetWhiteboard(){Mode=OverlayMode.Whiteboard;FrozenImage.Source=null;FrozenImage.Visibility=Visibility.Collapsed;Whiteboard.Visibility=Visibility.Visible;Surface.Background=Brushes.White;SetClickThrough(false);ModeChanged?.Invoke(this,EventArgs.Empty);}
    public void SetFreeze(){Visibility=Visibility.Hidden; Dispatcher.Invoke(()=>{},System.Windows.Threading.DispatcherPriority.Render); try{var vs=Forms.SystemInformation.VirtualScreen; using var bmp=new System.Drawing.Bitmap(vs.Width,vs.Height,System.Drawing.Imaging.PixelFormat.Format32bppArgb);using(var g=System.Drawing.Graphics.FromImage(bmp))g.CopyFromScreen(vs.Left,vs.Top,0,0,bmp.Size);var h=bmp.GetHbitmap();try{FrozenImage.Source=Imaging.CreateBitmapSourceFromHBitmap(h,nint.Zero,Int32Rect.Empty,BitmapSizeOptions.FromEmptyOptions());}finally{DeleteObject(h);}}finally{Visibility=Visibility.Visible;} Mode=OverlayMode.Freeze;Whiteboard.Visibility=Visibility.Collapsed;FrozenImage.Visibility=Visibility.Visible;Surface.Background=Brushes.Black;SetClickThrough(false);ModeChanged?.Invoke(this,EventArgs.Empty);}
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern bool DeleteObject(nint obj);
}
