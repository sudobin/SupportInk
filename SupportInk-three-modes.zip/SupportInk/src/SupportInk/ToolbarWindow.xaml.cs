using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
namespace SupportInk;
public partial class ToolbarWindow : Window
{
    private readonly OverlayWindow _overlay; private HwndSource? _source; private const int HotKeyId=9917;
    public ToolbarWindow(OverlayWindow overlay)
    {
        InitializeComponent(); _overlay=overlay; _overlay.ModeChanged += (_,__)=>UpdateMode();
        Loaded += (_,__)=>{Left=SystemParameters.WorkArea.Left+24; Top=SystemParameters.WorkArea.Bottom-Height-24;};
        SourceInitialized += (_,__)=>{var hwnd=new WindowInteropHelper(this).Handle; _source=HwndSource.FromHwnd(hwnd); _source.AddHook(WndProc); NativeMethods.RegisterHotKey(hwnd,HotKeyId,NativeMethods.MOD_CONTROL|NativeMethods.MOD_SHIFT,(uint)KeyInterop.VirtualKeyFromKey(Key.D));};
        Closed += (_,__)=>{var hwnd=new WindowInteropHelper(this).Handle; NativeMethods.UnregisterHotKey(hwnd,HotKeyId); _source?.RemoveHook(WndProc);};
        MouseLeftButtonDown += (_,e)=>{if(e.ButtonState==MouseButtonState.Pressed) DragMove();}; UpdateMode();
    }
    private nint WndProc(nint hwnd,int msg,nint wParam,nint lParam,ref bool handled){if(msg==NativeMethods.WM_HOTKEY && wParam==HotKeyId){_overlay.ToggleClickThrough(); handled=true;} return 0;}
    private void UpdateMode()=>Dispatcher.Invoke(()=>ModeButton.Content=_overlay.IsClickThrough?"Draw":"Interact");
    private void Live_Click(object s,RoutedEventArgs e)=>_overlay.SetLive();
    private void Freeze_Click(object s,RoutedEventArgs e)=>_overlay.SetFreeze();
    private void Whiteboard_Click(object s,RoutedEventArgs e)=>_overlay.SetWhiteboard();
    private void Mode_Click(object s,RoutedEventArgs e)=>_overlay.ToggleClickThrough();
    private void Red_Click(object s,RoutedEventArgs e)=>_overlay.SetPen(Colors.Red,4);
    private void Highlight_Click(object s,RoutedEventArgs e)=>_overlay.SetPen(Color.FromArgb(110,255,235,59),18,true);
    private void Eraser_Click(object s,RoutedEventArgs e)=>_overlay.SetEraser();
    private void Undo_Click(object s,RoutedEventArgs e)=>_overlay.Undo();
    private void Clear_Click(object s,RoutedEventArgs e)=>_overlay.Clear();
    private void Hide_Click(object s,RoutedEventArgs e)=>Hide();
    public void ShowAndActivate(){Show(); Activate();}
}
