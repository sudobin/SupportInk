using System.Windows;
using Forms = System.Windows.Forms;

namespace SupportInk;
public partial class App : Application
{
    private OverlayWindow? _overlay;
    private ToolbarWindow? _toolbar;
    private Forms.NotifyIcon? _tray;
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _overlay = new OverlayWindow();
        _toolbar = new ToolbarWindow(_overlay);
        _overlay.Show(); _toolbar.Show();
        _tray = new Forms.NotifyIcon { Text = "SupportInk", Visible = true, Icon = System.Drawing.SystemIcons.Information };
        var menu = new Forms.ContextMenuStrip();
        menu.Items.Add("Show toolbar", null, (_,__) => _toolbar.ShowAndActivate());
        menu.Items.Add("Clear", null, (_,__) => _overlay.Clear());
        menu.Items.Add("Exit", null, (_,__) => Shutdown());
        _tray.ContextMenuStrip = menu;
        _tray.DoubleClick += (_,__) => _toolbar.ShowAndActivate();
    }
    protected override void OnExit(ExitEventArgs e) { if (_tray is not null) { _tray.Visible=false; _tray.Dispose(); } base.OnExit(e); }
}
