using System.Runtime.InteropServices;
namespace SupportInk;
internal static class NativeMethods
{
    internal const int GWL_EXSTYLE=-20, WS_EX_TRANSPARENT=0x20, WS_EX_TOOLWINDOW=0x80, WS_EX_NOACTIVATE=0x08000000;
    internal const int WM_HOTKEY=0x0312, MOD_CONTROL=0x0002, MOD_SHIFT=0x0004;
    [DllImport("user32.dll", EntryPoint="GetWindowLongPtrW")] internal static extern nint GetWindowLongPtr(nint hWnd,int index);
    [DllImport("user32.dll", EntryPoint="SetWindowLongPtrW")] internal static extern nint SetWindowLongPtr(nint hWnd,int index,nint value);
    [DllImport("user32.dll")] [return:MarshalAs(UnmanagedType.Bool)] internal static extern bool RegisterHotKey(nint hWnd,int id,uint modifiers,uint key);
    [DllImport("user32.dll")] [return:MarshalAs(UnmanagedType.Bool)] internal static extern bool UnregisterHotKey(nint hWnd,int id);
}
